#define FFI_SCOPE "TEST_300"

int printf(const char *format, ...);
